# Surface Ropes for Blender 4.4

Draw ropes across a mesh, extend them, create over/under crossings and knots, and
compress the underlying surface. No external packages are needed in Blender.

## Install

1. Download `surface-ropes-0.1.0.zip` from the release artifacts.
2. In Blender 4.4, open **Edit → Preferences → Add-ons**.
3. Open the top-right menu and choose **Install from Disk**, then select the ZIP.
4. Enable **Surface Ropes**. In the 3D View, press **N** and open the **Ropes** tab.

Use the ZIP directly; do not unzip it before installing.

## Draw and edit

1. Select the object to wrap in **Object Mode** and click **Use Selected Surface**.
2. Set **Rope Radius** in Blender world units.
3. Click **Draw New Rope**, then left-click two points on the surface. A rope runs
   between them. Additional clicks extend the same rope through each new anchor.
4. Press **N** while drawing to begin a separate rope. The first click creates its
   starting anchor; the second creates a visible segment.
5. New ropes pass **under** existing ropes at transverse crossings. Self-crossings
   also work: the later part of the rope passes under the earlier part.
6. Right-click on any rope to add a knot; right-click it again to remove it.
   Right-click a crossing to toggle it between junction and knot.
7. Finish drawing with Enter. To reverse a crossing, select its entry in the junction list and click
   **Swap Over / Under**. This also determines which strand carries a junction knot.
8. Press **Enter** or **Esc** to finish and retain your edits. Right-clicking empty
   space also finishes. Use middle mouse / wheel / Alt gestures to navigate while
   drawing. Undo after finishing reverses the complete drawing session.
9. Choose a rope using **Active Rope**, then click **Extend / Edit Ropes** to resume
   it. Use **Remove Active Rope** to remove it and its junctions.

**Rebuild Ropes** applies changes to radius or routing detail. Rebuild after
editing the surface topology or changing its scale. Curves are parented to the
surface and follow ordinary object movement/rotation.

## Squishiness

**Squishiness** controls how readily the surface compresses; **Tightness** controls
indentation strength. **Indent Width** controls the spread of compression in
multiples of rope radius. These controls update the ropes and surface immediately.
Zero squishiness or tightness restores the original surface. Removing all ropes
also removes the visible compression.

The add-on uses its own **Ropes Compression** relative shape key. It leaves the
base mesh intact and preserves existing shape keys. Do not rename or manually
edit the add-on's compression key. Compression needs vertices near the rope:
subdivide a coarse mesh before drawing if you want visible, smooth indentations.
A shared mesh must be made single-user before compression can be enabled.

## Scope and practical limits

- Surface paths approximate the shortest route on a triangulated, subdivided copy
  of the mesh. Increase **Routing Detail** for better paths; large meshes and many
  ropes take longer. Disconnected mesh islands cannot be joined by a surface rope.
- Routing uses the original mesh, not modifier-generated geometry, sculpt masks,
  or the combined result of other animated shape keys. Apply required geometry
  modifiers before drawing. Use outward-facing normals and a manifold mesh for
  predictable placement. Uniform scale is supported; apply nonuniform scale.
- Crossings are detected within one rope radius on the same target. Nearly parallel
  strands are not treated as crossings. Tight neighboring crossings may merge.
- Knots are connected, open trefoil sections spliced into the rope curve. Junction
  knots place this section on the selected over strand. They are visual geometry,
  not a physically tied constraint or an interwoven knot tying both strands.
- Compression is a reversible geometric approximation, not soft-body physics.
  There is no collision solver, volume preservation, or physically calculated
  tension. Extreme compression or densely overlapping knots can intersect.
- Right-click knot editing works **inside Draw / Edit mode**. Ordinary Blender
  right-click behavior is preserved outside that mode. Picking uses a 16-pixel
  screen-distance threshold and does not resolve occlusion; orbit to the strand
  you want if several overlap. A mouse or tablet using mouse events is required.
- **Esc finishes and keeps the session**, rather than cancelling all clicks. Blender
  undo after finishing reverses that session. Save your `.blend` with the add-on
  enabled to retain editable anchors, knots, crossing choices, and compression.

## Development

Run the existing checkout directly; each cloud task is already isolated and does
not need a Git worktree. The add-on has no third-party runtime dependencies.

```sh
blender --background --factory-startup --python-exit-code 1 --python tests/blender_integration.py
python tools/package.py
```

The integration suite runs in Blender, including registration, paths on flat and
curved surfaces, extensions, crossings, self-crossings, over/under swaps, knots,
compression, disconnected-island rejection, transforms and saving/loading.
For the official Python module build of Blender 4.4, use the reproducible cloud
setup (Python 3.11 and hash-verified testing dependencies):

```sh
bash tools/setup-cloud.sh
```

This also packages the ZIP and verifies installation/enabling/disabling through
Blender's add-on API. The testing dependencies are for the cloud only; Blender
users just install the ZIP. NumPy 1.26 is pinned for Blender 4.4's native ABI.

Headless tests also exercise projected click and knot-picking math from a sidebar
context. They do not establish complete interactive viewport behavior. The manual
checklist in `tests/MANUAL.md` covers that final validation in Blender 4.4.
