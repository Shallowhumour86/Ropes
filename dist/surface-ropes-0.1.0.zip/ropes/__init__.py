bl_info = {
    'name': 'Surface Ropes',
    'author': 'Ropes contributors',
    'version': (0, 1, 0),
    'blender': (4, 4, 0),
    'location': '3D View > Sidebar > Ropes',
    'description': 'Draw ropes on a mesh, create crossings and knots, and indent the surface',
    'category': 'Object',
}

import json
import math
import uuid

import bpy
from bpy.props import (BoolProperty, CollectionProperty, FloatProperty,
                       FloatVectorProperty, IntProperty, PointerProperty, StringProperty)
from mathutils import Matrix, Vector
from mathutils.kdtree import KDTree
from bpy_extras import view3d_utils

from .geometry import (Surface, cumulative, crossings, knot_points,
                       point_segment_distance, sample_at, resample)


def mesh_poll(self, obj):
    return obj.type == 'MESH' and not obj.get('ropes_generated')


class ROPES_PG_Anchor(bpy.types.PropertyGroup):
    position: FloatVectorProperty(size=3)


class ROPES_PG_Knot(bpy.types.PropertyGroup):
    # Arc length from the start, so extension does not move existing knots.
    distance: FloatProperty(min=0)


class ROPES_PG_Rope(bpy.types.PropertyGroup):
    enabled: BoolProperty(default=False)
    target: PointerProperty(type=bpy.types.Object)
    anchors: CollectionProperty(type=ROPES_PG_Anchor)
    knots: CollectionProperty(type=ROPES_PG_Knot)
    uid: StringProperty()
    order: IntProperty(default=0)


class ROPES_PG_Junction(bpy.types.PropertyGroup):
    rope_a: PointerProperty(type=bpy.types.Object)
    rope_b: PointerProperty(type=bpy.types.Object)
    position: FloatVectorProperty(size=3)
    distance_a: FloatProperty()
    distance_b: FloatProperty()
    is_knot: BoolProperty(default=False)
    over_a: BoolProperty(default=True)
    uid: StringProperty()


def squish_update(self, context):
    if self.target is not None:
        try:
            refresh_render(context.scene, self.target)
            self.message = ''
        except (ValueError, RuntimeError) as exc:
            self.message = str(exc)


class ROPES_PG_Settings(bpy.types.PropertyGroup):
    target: PointerProperty(type=bpy.types.Object, poll=mesh_poll)
    active_rope: PointerProperty(type=bpy.types.Object)
    radius: FloatProperty(name='Rope Radius', default=.025, min=.001, soft_max=.2,
                          subtype='DISTANCE')
    subdivisions: IntProperty(name='Routing Detail', default=2, min=0, max=6)
    squish: FloatProperty(name='Squishiness', default=0, min=0, max=1, update=squish_update)
    tension: FloatProperty(name='Tightness', default=.5, min=0, max=1, update=squish_update)
    falloff: FloatProperty(name='Indent Width', default=4, min=1, max=20, update=squish_update)
    junctions: CollectionProperty(type=ROPES_PG_Junction)
    message: StringProperty()
    active_junction: IntProperty(default=0, min=0)


def rope_objects(scene, target):
    return sorted((o for o in scene.objects if o.type == 'CURVE' and
                   o.ropes_rope.enabled and o.ropes_rope.target == target),
                  key=lambda o: o.ropes_rope.order)


def generated_collection(scene):
    # Only reuse a collection we created; never adopt a user's named collection.
    for col in scene.collection.children:
        if col.get('ropes_collection'):
            return col
    col = bpy.data.collections.new('Surface Ropes')
    col['ropes_collection'] = True
    scene.collection.children.link(col)
    return col


def material():
    mat = bpy.data.materials.get('Surface Ropes · Fiber')
    if mat is None:
        mat = bpy.data.materials.new('Surface Ropes · Fiber')
        mat.diffuse_color = (.48, .26, .09, 1)
        mat.use_nodes = True
        bsdf = mat.node_tree.nodes.get('Principled BSDF')
        bsdf.inputs['Base Color'].default_value = (.48, .26, .09, 1)
        bsdf.inputs['Roughness'].default_value = .8
    return mat


def new_curve(scene, target, name):
    data = bpy.data.curves.new(name, 'CURVE')
    data.dimensions = '3D'
    data.resolution_u = 1
    data.bevel_resolution = 3
    data.use_fill_caps = True
    data.materials.append(material())
    obj = bpy.data.objects.new(name, data)
    generated_collection(scene).objects.link(obj)
    obj['ropes_generated'] = True
    obj.parent = target
    obj.matrix_parent_inverse = Matrix.Identity(4)
    obj.matrix_basis = Matrix.Identity(4)
    return obj


def set_curve(obj, points, radius, cyclic=False):
    obj.data.splines.clear()
    if len(points) < 2:
        return
    inverse = obj.parent.matrix_world.inverted_safe()
    spline = obj.data.splines.new('POLY')
    spline.points.add(len(points)-1)
    for p, world in zip(spline.points, points):
        local = inverse @ world
        p.co = (*local, 1)
    spline.use_cyclic_u = cyclic
    # Blender's bevel is in object space. Uniform scale is supported exactly.
    scale = sum(obj.parent.matrix_world.to_scale())/3
    obj.data.bevel_depth = radius/max(abs(scale), 1e-6)


def new_rope(scene, target):
    order = max((o.ropes_rope.order for o in rope_objects(scene, target)), default=-1)+1
    obj = new_curve(scene, target, 'Rope')
    obj.ropes_rope.enabled = True
    obj.ropes_rope.target = target
    obj.ropes_rope.uid = uuid.uuid4().hex
    obj.ropes_rope.order = order
    scene.ropes_settings.active_rope = obj
    return obj


def rest_path(rope):
    target = rope.ropes_rope.target
    return [target.matrix_world @ Vector(p) for p in json.loads(rope.get('ropes_path', '[]'))]


def visible_path(rope):
    if not rope.data.splines:
        return []
    return [rope.matrix_world @ Vector(p.co[:3]) for p in rope.data.splines[0].points]


def remove_helpers(scene, target):
    for obj in list(scene.objects):
        if obj.get('ropes_helper') and obj.parent == target:
            data = obj.data
            bpy.data.objects.remove(obj, do_unlink=True)
            if data.users == 0:
                bpy.data.curves.remove(data)


def rebuild(scene, target):
    settings = scene.ropes_settings
    surface = Surface(target, settings.subdivisions)
    ropes = rope_objects(scene, target)
    paths = {}
    inverse = target.matrix_world.inverted_safe()
    for rope in ropes:
        anchors = [target.matrix_world @ Vector(a.position) for a in rope.ropes_rope.anchors]
        path = []
        for a, b in zip(anchors, anchors[1:]):
            leg = surface.route(a, b)
            path.extend(leg if not path else leg[1:])
        rope['ropes_path'] = json.dumps([list(inverse @ p) for p in path])
        if len(path) > 1:
            paths[rope.name] = path
    active_uid = (settings.junctions[settings.active_junction].uid
                  if settings.active_junction < len(settings.junctions) else None)
    old = [dict(a=j.rope_a, b=j.rope_b, p=Vector(j.position), knot=j.is_knot,
                over_a=j.over_a, uid=j.uid)
           for j in settings.junctions if j.rope_a and j.rope_a.ropes_rope.target == target]
    for index in reversed(range(len(settings.junctions))):
        j = settings.junctions[index]
        if j.rope_a is None or j.rope_a.ropes_rope.target == target:
            settings.junctions.remove(index)
    radius = settings.radius
    for crossing in crossings(paths, radius):
        j = settings.junctions.add()
        j.rope_a = scene.objects[crossing['a']]
        j.rope_b = scene.objects[crossing['b']]
        j.position = inverse @ crossing['center']
        j.distance_a, j.distance_b = crossing['sa'], crossing['sb']
        j.uid = uuid.uuid4().hex
        matches = [o for o in old if o['a'] == j.rope_a and o['b'] == j.rope_b and
                   (target.matrix_world @ o['p']-crossing['center']).length < radius*8]
        if matches:
            match = min(matches, key=lambda o: (target.matrix_world @ o['p']-crossing['center']).length)
            j.is_knot, j.uid, j.over_a = match['knot'], match['uid'], match['over_a']
    if active_uid:
        for i, junction in enumerate(settings.junctions):
            if junction.uid == active_uid:
                settings.active_junction = i
                break
    render_ropes(scene, target, surface, ropes, paths)


def refresh_render(scene, target):
    surface = Surface(target, 0)
    ropes = rope_objects(scene, target)
    paths = {r.name: rest_path(r) for r in ropes if len(rest_path(r)) > 1}
    render_ropes(scene, target, surface, ropes, paths)


def render_ropes(scene, target, surface, ropes, paths):
    settings = scene.ropes_settings
    radius = settings.radius
    remove_helpers(scene, target)
    for rope in ropes:
        path = paths.get(rope.name, [])
        if not path:
            set_curve(rope, [], radius)
            continue
        lengths = cumulative(path)
        rendered = []
        junctions = [j for j in settings.junctions if
                     (j.rope_a == rope and j.over_a) or (j.rope_b == rope and not j.over_a)]
        for p, s in zip(path, lengths):
            _, normal, _ = surface.project(p)
            lift = radius*1.05 - radius*2*settings.squish*settings.tension
            for j in junctions:
                # The first rope stays over by default; the new rope passes under.
                station = j.distance_a if j.over_a else j.distance_b
                delta = abs(s-station)
                if delta < radius*6:
                    lift += radius*2.3*.5*(1+math.cos(math.pi*delta/(radius*6)))
            rendered.append(p + normal*lift)
        knot_stations = [k.distance for k in rope.ropes_rope.knots]
        for j in settings.junctions:
            if j.is_knot:
                if j.over_a and j.rope_a == rope:
                    knot_stations.append(j.distance_a)
                elif not j.over_a and j.rope_b == rope:
                    knot_stations.append(j.distance_b)
        rendered, stations = insert_knots(scene, surface, path, lengths, rendered,
                                          knot_stations, radius)
        set_curve(rope, rendered, radius)
        rope['ropes_stations'] = json.dumps(stations)
    deform(scene, target)
    bpy.context.view_layer.update()
    settings.message = ''


def insert_knots(scene, surface, path, lengths, rendered, knot_stations, radius):
    # Splice an open trefoil into the actual curve, with connected entering and
    # exiting leads. Arc stations remain mapped to the undeformed surface path.
    knots = sorted(set(max(0, min(lengths[-1], s)) for s in knot_stations))
    if not knots:
        return rendered, lengths
    result, stations = [], []
    i = 0
    compression = radius*2*scene.ropes_settings.squish*scene.ropes_settings.tension
    for station in knots:
        low, high = max(0, station-radius*6), min(lengths[-1], station+radius*6)
        while i < len(lengths) and lengths[i] < low:
            result.append(rendered[i])
            stations.append(lengths[i])
            i += 1
        center, tangent = sample_at(path, lengths, station)
        _, normal, _ = surface.project(center)
        p, _ = sample_at(path, lengths, low)
        _, n, _ = surface.project(p)
        result.append(p+n*(radius*1.05-compression))
        stations.append(low)
        loop = knot_points(center+normal*(radius-compression), tangent, normal, radius*1.5)
        # The omitted closing edge opens the trefoil so it belongs to this rope.
        result.extend(loop)
        stations.extend([station]*len(loop))
        p, _ = sample_at(path, lengths, high)
        _, n, _ = surface.project(p)
        result.append(p+n*(radius*1.05-compression))
        stations.append(high)
        while i < len(lengths) and lengths[i] <= high:
            i += 1
    result.extend(rendered[i:])
    stations.extend(lengths[i:])
    return result, stations


def deform(scene, target):
    settings = scene.ropes_settings
    key_name = target.get('ropes_compression_key')
    keys = target.data.shape_keys
    if settings.squish == 0 or settings.tension == 0:
        if key_name and keys and key_name in keys.key_blocks:
            keys.key_blocks[key_name].value = 0
        return
    ropes = rope_objects(scene, target)
    paths = [rest_path(r) for r in ropes]
    segments = [(a, b) for path in paths for a, b in zip(path, path[1:])]
    if not segments:
        if key_name and keys and key_name in keys.key_blocks:
            keys.key_blocks[key_name].value = 0
        return
    if target.data.users > 1:
        raise ValueError('Make the surface mesh single-user before enabling squishiness.')
    if keys and not keys.use_relative:
        raise ValueError('Squishiness requires relative shape keys.')
    if not keys:
        target.shape_key_add(name='Basis', from_mix=False)
        keys = target.data.shape_keys
    if not key_name or key_name not in keys.key_blocks:
        key = target.shape_key_add(name='Ropes Compression', from_mix=False)
        key_name = key.name
        target['ropes_compression_key'] = key_name
    key = target.data.shape_keys.key_blocks[key_name]
    basis = target.data.shape_keys.reference_key
    inverse = target.matrix_world.inverted_safe()
    normal_matrix = target.matrix_world.to_3x3().inverted_safe().transposed()
    width = settings.radius*settings.falloff
    depth = settings.radius*2*settings.squish*settings.tension
    # Sampled contact points limit the nearest-segment search without evaluating
    # every rope segment for every surface vertex.
    samples = []
    contacts = []
    for a, b in segments:
        index = len(contacts)
        contacts.append((a, b))
        for point in resample([a, b], width/2):
            samples.append((point, index))
    tree = KDTree(len(samples))
    for i, (point, _) in enumerate(samples):
        tree.insert(point, i)
    tree.balance()
    for vertex, base, output in zip(target.data.vertices, basis.data, key.data):
        p = target.matrix_world @ base.co
        candidates = {samples[i][1] for _, i, _ in tree.find_n(p, min(8, len(samples)))}
        distance = min(point_segment_distance(p, *contacts[i]) for i in candidates)
        influence = math.exp(-2*(distance/width)**2) if distance < width*3 else 0
        normal = (normal_matrix @ vertex.normal).normalized()
        output.co = inverse @ (p-normal*depth*influence)
    key.value = 1
    target.data.update()


def knot_at(scene, rope, distance):
    """Toggle crossing knot first; otherwise toggle a manual knot at this station."""
    settings = scene.ropes_settings
    target = rope.ropes_rope.target
    radius = settings.radius
    junctions = [j for j in settings.junctions if
                 (j.rope_a == rope and abs(j.distance_a-distance) < radius*7) or
                 (j.rope_b == rope and abs(j.distance_b-distance) < radius*7)]
    if junctions:
        j = min(junctions, key=lambda j: min(
            [abs(j.distance_a-distance)] if j.rope_b != rope else
            [abs(j.distance_b-distance)] if j.rope_a != rope else
            [abs(j.distance_a-distance), abs(j.distance_b-distance)]))
        j.is_knot = not j.is_knot
        settings.active_junction = list(settings.junctions).index(j)
    else:
        knots = rope.ropes_rope.knots
        closest = next((i for i, k in enumerate(knots) if abs(k.distance-distance) < radius*5), None)
        if closest is not None:
            knots.remove(closest)
        else:
            knots.add().distance = distance
    rebuild(scene, target)


class ROPES_OT_Rebuild(bpy.types.Operator):
    bl_idname = 'ropes.rebuild'
    bl_label = 'Rebuild Ropes'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        target = context.scene.ropes_settings.target
        if not target:
            self.report({'ERROR'}, 'Choose a surface mesh first.')
            return {'CANCELLED'}
        try:
            rebuild(context.scene, target)
        except (ValueError, RuntimeError) as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        return {'FINISHED'}


class ROPES_OT_UseSelected(bpy.types.Operator):
    bl_idname = 'ropes.use_selected'
    bl_label = 'Use Selected Surface'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or not mesh_poll(None, obj):
            self.report({'ERROR'}, 'Select the mesh you want to wrap.')
            return {'CANCELLED'}
        context.scene.ropes_settings.target = obj
        return {'FINISHED'}


def screen_pick(context, event, ropes, region=None, rv3d=None):
    region = region or context.region
    rv3d = rv3d or context.region_data
    mouse = Vector((event.mouse_x-region.x, event.mouse_y-region.y))
    best = None
    best_distance = 16.0
    for rope in ropes:
        path = visible_path(rope)
        rest = rest_path(rope)
        if len(path) < 2 or len(rest) < 2:
            continue
        lengths = json.loads(rope.get('ropes_stations', '[]'))
        if len(lengths) != len(path):
            continue
        for i, (a, b) in enumerate(zip(path, path[1:])):
            sa = view3d_utils.location_3d_to_region_2d(region, rv3d, a)
            sb = view3d_utils.location_3d_to_region_2d(region, rv3d, b)
            if sa is None or sb is None:
                continue
            delta = sb-sa
            t = max(0.0, min(1.0, (mouse-sa).dot(delta)/delta.length_squared)) if delta.length_squared else 0
            d = (mouse-sa-delta*t).length
            if d < best_distance:
                best_distance = d
                best = rope, lengths[i]+t*(lengths[i+1]-lengths[i])
    return best


class ROPES_OT_Draw(bpy.types.Operator):
    bl_idname = 'ropes.draw'
    bl_label = 'Draw / Edit Ropes'
    bl_description = 'Click surface anchors; N starts a rope; right-click a rope toggles a knot'
    bl_options = {'REGISTER', 'UNDO', 'BLOCKING'}
    extend: BoolProperty(default=False)

    def invoke(self, context, event):
        settings = context.scene.ropes_settings
        target = settings.target
        if context.mode != 'OBJECT' or context.area.type != 'VIEW_3D':
            self.report({'ERROR'}, 'Use Object Mode in a 3D View.')
            return {'CANCELLED'}
        if not target or target.type != 'MESH':
            self.report({'ERROR'}, 'Choose a surface mesh first.')
            return {'CANCELLED'}
        try:
            self.surface = Surface(target, settings.subdivisions)
        except (ValueError, RuntimeError) as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        self.area = context.area
        self.region = next(r for r in self.area.regions if r.type == 'WINDOW')
        self.rv3d = context.space_data.region_3d
        self.target = target
        self.rope = settings.active_rope if self.extend else None
        if self.rope and (not self.rope.ropes_rope.enabled or self.rope.ropes_rope.target != target):
            self.rope = None
        context.window_manager.modal_handler_add(self)
        context.area.header_text_set('Ropes: LMB add point · N new rope · RMB on rope knot/crossing · Enter/Esc finish · Ctrl+Z after finishing to undo')
        return {'RUNNING_MODAL'}

    def finish(self, context):
        self.area.header_text_set(None)
        self.area.tag_redraw()
        return {'FINISHED'}

    def modal(self, context, event):
        if event.type in {'ESC', 'RET', 'NUMPAD_ENTER'} and event.value == 'PRESS':
            return self.finish(context)
        if event.type == 'N' and event.value == 'PRESS':
            self.rope = None
            return {'RUNNING_MODAL'}
        if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE'} or event.alt:
            return {'PASS_THROUGH'}
        if event.value != 'PRESS':
            return {'RUNNING_MODAL'}
        if not (self.region.x <= event.mouse_x < self.region.x+self.region.width and
                self.region.y <= event.mouse_y < self.region.y+self.region.height):
            return {'RUNNING_MODAL'}
        try:
            if event.type == 'RIGHTMOUSE':
                pick = screen_pick(context, event, rope_objects(context.scene, self.target), self.region, self.rv3d)
                if pick:
                    knot_at(context.scene, *pick)
                    context.area.tag_redraw()
                    return {'RUNNING_MODAL'}
                return self.finish(context)
            if event.type == 'LEFTMOUSE':
                origin = view3d_utils.region_2d_to_origin_3d(self.region, self.rv3d,
                                                          (event.mouse_x-self.region.x, event.mouse_y-self.region.y))
                direction = view3d_utils.region_2d_to_vector_3d(self.region, self.rv3d,
                                                             (event.mouse_x-self.region.x, event.mouse_y-self.region.y))
                point, _, _, _ = self.surface.bvh.ray_cast(origin, direction)
                if point is None:
                    self.report({'INFO'}, 'Click on the chosen surface.')
                    return {'RUNNING_MODAL'}
                if self.rope is None:
                    self.rope = new_rope(context.scene, self.target)
                anchors = self.rope.ropes_rope.anchors
                if anchors and (self.target.matrix_world @ Vector(anchors[-1].position)-point).length < 1e-5:
                    return {'RUNNING_MODAL'}
                anchor = anchors.add()
                anchor.position = self.target.matrix_world.inverted_safe() @ point
                try:
                    rebuild(context.scene, self.target)
                except (ValueError, RuntimeError):
                    anchors.remove(len(anchors)-1)
                    rebuild(context.scene, self.target)
                    raise
                context.scene.ropes_settings.active_rope = self.rope
                context.area.tag_redraw()
        except (ValueError, RuntimeError) as exc:
            self.report({'ERROR'}, str(exc))
        return {'RUNNING_MODAL'}


class ROPES_OT_Remove(bpy.types.Operator):
    bl_idname = 'ropes.remove'
    bl_label = 'Remove Active Rope'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        settings = context.scene.ropes_settings
        rope = settings.active_rope
        if not rope or not rope.ropes_rope.enabled:
            return {'CANCELLED'}
        target, data = rope.ropes_rope.target, rope.data
        settings.active_rope = None
        bpy.data.objects.remove(rope, do_unlink=True)
        if data.users == 0:
            bpy.data.curves.remove(data)
        if target:
            try:
                rebuild(context.scene, target)
            except (ValueError, RuntimeError) as exc:
                self.report({'ERROR'}, str(exc))
                return {'CANCELLED'}
        return {'FINISHED'}


class ROPES_UL_Junctions(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        a = item.rope_a.name if item.rope_a else '?'
        b = item.rope_b.name if item.rope_b else '?'
        layout.label(text=f'{a} / {b}', icon='CURVE_DATA' if not item.is_knot else 'LINKED')


class ROPES_OT_SwapCrossing(bpy.types.Operator):
    bl_idname = 'ropes.swap_crossing'
    bl_label = 'Swap Over / Under'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        settings = context.scene.ropes_settings
        if settings.active_junction >= len(settings.junctions):
            return {'CANCELLED'}
        j = settings.junctions[settings.active_junction]
        if not j.rope_a:
            return {'CANCELLED'}
        j.over_a = not j.over_a
        try:
            rebuild(context.scene, j.rope_a.ropes_rope.target)
        except (ValueError, RuntimeError) as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        return {'FINISHED'}


class ROPES_PT_Panel(bpy.types.Panel):
    bl_label = 'Surface Ropes'
    bl_idname = 'ROPES_PT_surface'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Ropes'

    def draw(self, context):
        layout = self.layout
        settings = context.scene.ropes_settings
        layout.prop(settings, 'target', text='Surface')
        layout.operator('ropes.use_selected', icon='EYEDROPPER')
        layout.prop(settings, 'radius')
        layout.prop(settings, 'subdivisions')
        layout.operator('ropes.draw', text='Draw New Rope', icon='CURVE_DATA').extend = False
        layout.prop(settings, 'active_rope', text='Active Rope')
        layout.operator('ropes.draw', text='Extend / Edit Ropes').extend = True
        layout.operator('ropes.rebuild', icon='FILE_REFRESH')
        layout.operator('ropes.remove', icon='TRASH')
        if settings.junctions:
            layout.template_list('ROPES_UL_Junctions', '', settings, 'junctions',
                                 settings, 'active_junction', rows=3)
            layout.operator('ropes.swap_crossing', icon='SORT_ASC')
        box = layout.box()
        box.label(text='Surface Compression')
        box.prop(settings, 'squish', slider=True)
        box.prop(settings, 'tension', slider=True)
        box.prop(settings, 'falloff')
        if settings.message:
            box.label(text=settings.message, icon='ERROR')
        layout.label(text='LMB: add surface point')
        layout.label(text='N: start another rope')
        layout.label(text='RMB rope: knot / junction')
        layout.label(text='Enter / Esc: finish')


CLASSES = (ROPES_PG_Anchor, ROPES_PG_Knot, ROPES_PG_Rope, ROPES_PG_Junction,
           ROPES_PG_Settings, ROPES_OT_Rebuild, ROPES_OT_UseSelected,
           ROPES_OT_Draw, ROPES_OT_Remove, ROPES_UL_Junctions,
           ROPES_OT_SwapCrossing, ROPES_PT_Panel)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Object.ropes_rope = PointerProperty(type=ROPES_PG_Rope)
    bpy.types.Scene.ropes_settings = PointerProperty(type=ROPES_PG_Settings)


def unregister():
    del bpy.types.Scene.ropes_settings
    del bpy.types.Object.ropes_rope
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
